原版 SpiderCat 越狱需要连接 WiFi，部分网络不通畅的小伙伴无法完成其中需要网络请求的步骤。为此，书伴（bookfere.com） 提供了此离线修改版，无需连接 WiFi，具体步骤如下：

1. 用 USB 数据线将 Kindle 连接至电脑，直至出现 Kindle 磁盘；；
2. 将 jb.so 和 jb.sh 拷贝到 Kindle 根目录；
3. 将 spidercat.azw3 拷贝到 Kindle 的 documents 目录；
4. 弹出 Kindle 磁盘或断开 Kindle 与电脑的 USB 连接；
5. 进入 Kindle 后再图书馆，点击名为 SpiderCat 的电子书；
6. 稍等片刻，Kindle 屏幕出现越狱相关信息，越狱成功。

详细信息参考文章：https://bookfere.com/post/1194.html
